package com.basar.app;

import android.Manifest;
import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.widget.ImageView;
import android.content.ActivityNotFoundException;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(48, 48, 48, 48);

        box.setBackgroundColor(0xFF05070F);

        ImageView photo = new ImageView(this);
        photo.setImageResource(R.drawable.photo);
        photo.setAdjustViewBounds(true);
        box.addView(photo, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView title = new TextView(this);
        title.setText("BASAR");
        title.setTextSize(40);
        title.setTextColor(0xFF1E9BFF);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        Button start = new Button(this);
        start.setText("চালু করুন");
        start.setOnClickListener(v -> begin());
        style(start);
        box.addView(start);

        Button stop = new Button(this);
        stop.setText("বন্ধ করুন");
        stop.setOnClickListener(v -> stopService(new Intent(this, BasarService.class)));
        style(stop);
        box.addView(stop);
        Button offline = new Button(this);
        offline.setText("অফলাইন সেটআপ");
        offline.setOnClickListener(v -> setupOffline());
        style(offline);
        box.addView(offline);
        setContentView(box);
    }

    private void style(Button b) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF0B1B3A);
        bg.setStroke(4, 0xFF1E9BFF);
        bg.setCornerRadius(60);
        b.setBackground(bg);
        b.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 24;
        b.setLayoutParams(p);
    }

    private SpeechRecognizer downloader;

    private void setupOffline() {
        if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isRecognitionAvailable(this)) {
            if (downloader == null) downloader = SpeechRecognizer.createSpeechRecognizer(this);
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
            downloader.triggerModelDownload(i);
            Toast.makeText(this, "বাংলা ভয়েস ডাউনলোডের অনুরোধ পাঠানো হয়েছে", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Google অ্যাপ থেকে বাংলা অফলাইন ভয়েস নামান", Toast.LENGTH_LONG).show();
        }
        try {
            startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "ফোনের Text-to-speech সেটিংস থেকে বাংলা নামান", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        if (downloader != null) downloader.destroy();
        super.onDestroy();
    }

    private void begin() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            String[] p = Build.VERSION.SDK_INT >= 33
                ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
                : new String[]{Manifest.permission.RECORD_AUDIO};
            requestPermissions(p, 1);
            Toast.makeText(this, "অনুমতি দিয়ে আবার চাপুন", Toast.LENGTH_LONG).show();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
            return;
        }
        startForegroundService(new Intent(this, BasarService.class));
    }
}
