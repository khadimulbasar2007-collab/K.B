package com.basar.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Locale;

public class BasarService extends Service implements RecognitionListener {
    private static final String REPLY =
        "আমি এখানে, আমার মালিক। খুঁজে দেওয়ার জন্য ধন্যবাদ, খাদিমুল বাশার।";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable listen = this::listen;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private Button bubble;
    private boolean speaking;
    private boolean preferOffline = true;

    private static String norm(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFC).toLowerCase(Locale.ROOT);
    }

    private static boolean has(String text, String... words) {
        for (String w : words) if (text.contains(norm(w))) return true;
        return false;
    }

    private boolean check(Bundle b) {
        ArrayList<String> list = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (list == null) return false;
        if (!list.isEmpty() && !list.get(0).isEmpty()) bubble.setText(list.get(0));
        for (String s : list) {
            String t = norm(s);
            boolean who = has(t, "মোবাইল", "বাশার", "বাসার", "ফোন", "mobile", "basar", "phone");
            boolean where = has(t, "কোথা", "কোথায়", "কই", "কোতায়", "কোটায়", "kothay", "where");
            if (who && where) return true;
        }
        return false;
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("basar", "BASAR", NotificationManager.IMPORTANCE_LOW));
        startForeground(1, new Notification.Builder(this, "basar")
            .setContentTitle("BASAR শুনছে")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build());

        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;
            tts.setLanguage(new Locale("bn", "BD"));
            tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM).build());
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                public void onStart(String id) {}
                public void onDone(String id) { resume(); }
                public void onError(String id) { resume(); }
            });
        });

        bubble = new Button(this);
        bubble.setText("BASAR");
        bubble.setTextColor(Color.WHITE);
        bubble.setBackgroundColor(Color.rgb(30, 90, 200));
        bubble.setOnClickListener(v -> answer());
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        getSystemService(WindowManager.class).addView(bubble, lp);

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(this);
            listen();
        } else {
            bubble.setText("Voice নেই");
        }
    }

    private void listen() {
        if (recognizer == null || speaking) return;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizer.startListening(i);
    }

    private void again(long delay) {
        handler.removeCallbacks(listen);
        handler.postDelayed(listen, delay);
    }

    private void answer() {
        speaking = true;
        handler.removeCallbacks(listen);
        if (recognizer != null) recognizer.cancel();
        AudioManager am = getSystemService(AudioManager.class);
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
        if (tts.speak(REPLY, TextToSpeech.QUEUE_FLUSH, null, "r") != TextToSpeech.SUCCESS) resume();
    }

    private void resume() {
        handler.post(() -> { speaking = false; again(500); });
    }

    @Override
    public void onResults(Bundle b) {
        if (speaking) return;
        if (check(b)) answer(); else again(300);
    }

    @Override
    public void onError(int error) {
        if (speaking) return;
        if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            bubble.setText("সমস্যা " + error);
            if (error == 2 || error == 12 || error == 13) preferOffline = !preferOffline;
        }
        again(1500);
    }

    @Override public void onReadyForSpeech(Bundle p) { bubble.setText("শুনছি..."); }
    @Override public void onBeginningOfSpeech() {}
    @Override public void onRmsChanged(float r) {}
    @Override public void onBufferReceived(byte[] b) {}
    @Override public void onEndOfSpeech() {}
    @Override public void onPartialResults(Bundle p) { if (!speaking && check(p)) answer(); }
    @Override public void onEvent(int type, Bundle p) {}

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        if (bubble != null) getSystemService(WindowManager.class).removeView(bubble);
        super.onDestroy();
    }
}
